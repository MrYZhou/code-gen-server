package com.lar.main.plan.model;

public class PlanInfo {
}
